This is simply the code from the MPI matrix multiplication homework. 

To run:
`make pmm`
`mpirun -np 6 ./pmm`