Instructions for running Hadoop Matrix Multiplication are in HadoopMatrixMultiplication folder in a README. The MPI Matrix multiplication is from Homework 7 and was used as reference in the in the project so I included it here. It has a README as well.

The code from HadoopMatrixMultiplication references this article: http://hadoopgeek.com/mapreduce-matrix-multiplication/

It helped me figure out a lot of the boilerplate code and understand the algorithm, and then I implemented the map and reduce static classes within MatrixMultiplyMR.java. 
